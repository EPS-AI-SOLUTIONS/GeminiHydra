# Memory of Eskel
