# Memory of Dijkstra
